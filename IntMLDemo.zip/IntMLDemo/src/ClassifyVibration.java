import java.util.ArrayList;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import processing.core.PApplet;
import processing.sound.AudioIn;
import processing.sound.FFT;
import processing.sound.SinOsc;
import processing.sound.Sound;
import processing.sound.Waveform;

import weka.core.SerializationHelper;
import weka.classifiers.functions.SMO;
import weka.core.Attribute;
/* A class with the main function and Processing visualizations to run the demo */

public class ClassifyVibration extends PApplet {

	FFT fft;
	AudioIn in;
	Waveform waveform;
	int bands = 512;
	int nsamples = 1024;
	float[] spectrum = new float[bands];
	float[] fftFeatures = new float[bands];
	String[] classNames = {"quiet", "chord1", "chord2"};
	int classIndex = 0;
	int dataCount = 0;
	long first_time;
	long current_time;
	int flag = 0;
	float y;
	float w = 512/(bands/8);
	boolean demo = false;
	boolean chord = false;
	String last_label;
	SinOsc sine;
	
	MLClassifier classifier;
	
	Map<String, List<DataInstance>> trainingData = new HashMap<>();
	{for (String className : classNames){
		trainingData.put(className, new ArrayList<DataInstance>());
	}}
	
	DataInstance captureInstance (String label){
		DataInstance res = new DataInstance();
		res.label = label;
		res.measurements = fftFeatures.clone();
		//System.out.println(res.measurements);
		return res;
	}
	
	public static void main(String[] args) {
		PApplet.main("ClassifyVibration");
	}
	
	public void settings() {
		size(512, 400);
	}

	public void setup() {
		colorMode(HSB);
		/* list all audio devices */
		Sound.list();
		Sound s = new Sound(this);
		  
		/* select microphone device */
		s.inputDevice(8);
		    
		/* create an Input stream which is routed into the FFT analyzer */
		fft = new FFT(this, bands);
		in = new AudioIn(this, 0);
		waveform = new Waveform(this, nsamples);
		waveform.input(in);
		
		/* start the Audio Input */
		in.start();
		  
		/* patch the AudioIn */
		fft.input(in);
		
		/* add from processing*/
		sine = new SinOsc(this);
		sine.freq(17500);
		sine.play();
		
	}

	public void draw() {
		background(0);
		fill(0);
		stroke(255);
		smooth();
		
		waveform.analyze();

		beginShape();
		  
		for(int i = 0; i < nsamples; i++)
		{
			vertex(
					map(i, 0, nsamples, 0, width),
					map(waveform.data[i], -1, 1, height/2, height)
					);
		}
		
		endShape();
		drawstring();
		fft.analyze(spectrum);

		for(int i = 0; i < bands/8; i++){
			/* the result of the FFT is normalized */
			/* draw the line for frequency band i scaling it up by 40 to get more amplitude */
			y = map(spectrum[i]*4,0, 1, height, 0);
			//println(y);
			fill(255-i*7, 255-i*4, 255-i*4);
			rect(i*w, y, w, y*10);
		} 
		
		for(int i = 0; i < bands; i++){
			fftFeatures[i] = spectrum[i];
		}
		
		fill(255);
		textSize(30);
		if(classifier != null) {
			String guessedLabel = classifier.classify(captureInstance(null));
			choosestring(guessedLabel);
			choosechord(guessedLabel);
			textSize(30);
			fill(255);
			//if we consider 2, 3, 4, 5, as quiet, then enable this part
			if(guessedLabel.equals((String) "2") || guessedLabel.equals((String) "3") || guessedLabel.equals((String) "4") || guessedLabel.equals((String) "5"))
			{
				if(demo)
				{
					guessedLabel = "quiet";
				}
			}
			if(chord)
			{
				if(guessedLabel != "quiet")
				{
					if(flag == 0)
					{
						text("classified as: " + guessedLabel, 20, 30);
						last_label = guessedLabel;
						first_time = System.currentTimeMillis();
						flag = 1;
					}
					else {
						current_time = System.currentTimeMillis();
						if ((current_time - first_time) > 0 )
						{
							text("classified as: " + guessedLabel, 20, 30);
							flag = 0;
							first_time = System.currentTimeMillis();
						}
						else {
							text("classified as: " + last_label, 20, 30);
						}
					}
				}
				if(guessedLabel == "quiet")
				{
					text("classified as: " + guessedLabel, 20, 30);
				}
			}
			else {
				text("classified as: " + guessedLabel, 20, 30);
			}
		}else {
			text(classNames[classIndex], 20, 30);
			dataCount = trainingData.get(classNames[classIndex]).size();
			text("Data collected: " + dataCount, 20, 60);
		}
	}
	public void drawstring() {
		  float h = height/4;
		  line(20, h+75, width, h+75);
		  line(20, h+60, width, h+60);
		  line(20, h+45, width, h+45);
		  line(20, h+30, width, h+30);
		  line(20, h+15, width, h+15);
		  line(20, h, width, h);
		  
		  line(20+width/8*0, h, 20+width/8*0, h+75);
		  line(20+width/8*1, h, 20+width/8*1, h+75);
		  line(20+width/8*2, h, 20+width/8*2, h+75);
		  line(20+width/8*3, h, 20+width/8*3, h+75);
		  line(20+width/8*4, h, 20+width/8*4, h+75);
		  fill(255);
		  textSize(14);
		  text("6", 5, h+75+5);
		  text("5", 5, h+60+5);
		  text("4", 5, h+45+5);
		  text("3", 5, h+30+5);
		  text("2", 5, h+15+5);
		  text("1", 5, h+5);
	}
	public void choosestring(String guessedLabel) {
		  float h = height/4;
		  if(guessedLabel.equals((String) "6")){
			  fill(0, 255, 255);
			  rect(20, h+74, width, 3);
		  }
		  else if(guessedLabel.equals((String) "5")){
			  fill(0, 255, 255);
			  rect(20, h+59, width, 3);
		  }
		  else if(guessedLabel.equals((String) "4")){
			  fill(0, 255, 255);
			  rect(20, h+44, width, 3);
		  }
		  else if(guessedLabel.equals((String) "3")){
			  fill(0, 255, 255);
			  rect(20, h+29, width, 3);
		  }
		  else if(guessedLabel.equals((String) "2")){
			  fill(0, 255, 255);
			  rect(20, h+14, width, 3);
		  }
		  else if(guessedLabel.equals((String) "1")){
			  fill(0, 255, 255);
			  rect(20, h-1, width, 3);
		  }
	}
	
    public void choosechord(String guessedLabel) {
		  float h = height/4;
		  if(guessedLabel.equals((String) "chord1")){
			  fill(0, 255, 255);
              circle(70, h+15, 13);
              circle(70+width/8, h+45, 13);
              circle(70+width/4, h+60, 13);
              fill(255);
              textSize(12);
              text("1", 67, h+19);
              text("2", 67+width/8, h+49);
              text("3", 67+width/4, h+64);
		  }
		  if(guessedLabel.equals((String) "chord2")){
			  fill(0, 255, 255);
              circle(70+width/8, h, 13);
              circle(70+width/8, h+45, 13);
              circle(70+width/4, h+30, 13);
              fill(255);
              textSize(12);
              text("1", 67+width/8, h+49);
              text("2", 67+width/8, h+4);
              text("3", 67+width/4, h+34);
		  }
    }	
	public void keyPressed() {
		if (key == '.') {
			classIndex = (classIndex + 1) % classNames.length;
		}
		
		else if (key == 't') {
			if(classifier == null) {
				println("Start training ...");
				classifier = new MLClassifier();
				classifier.train(trainingData);
			}else {
				classifier = null;
			}
		}
		else if (key == 's')
		{
			if(classifier != null)
			{
				try {
					SerializationHelper.write("test424-5.model", classifier.classifier);
					SerializationHelper.write("test424-5.attr", classifier.classattr);
					SerializationHelper.write("test424-5.data", trainingData); // save the training data
					System.out.println("model saved");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else {
				text("No model to be saved!", 20, 30);
			}
		}
		else if (key == 'l') {
			if(true) {
				System.out.println("generating new object");
				classifier = new MLClassifier();
				try {
					demo = false;
					chord = false;
					//classifier.classifier = (SMO) weka.core.SerializationHelper.read("test421-1.model");
					//classifier.classattr = (Attribute) weka.core.SerializationHelper.read("test421-1.attr");
					trainingData = (Map<String, List<DataInstance>>) weka.core.SerializationHelper.read("test424-3.data");
					classifier.train(trainingData);
					/*
					List address = new ArrayList();
					address.add("1");
					address.add("quiet");
					address.add("2");
					address.add("3");
					address.add("4");
					address.add("5");
					address.add("6");
					classifier.featureCalc = new FeatureCalc(address);
					
					if(classifier.featureCalc == null)
					{
						System.out.println("It is truely null");
					}
					*/
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			String guessedLabel = classifier.classify(captureInstance(null));
			text("classified as: " + guessedLabel, 20, 30);
		}
		else if (key == 'd') {
			if(true) {
				System.out.println("generating new object");
				classifier = new MLClassifier();
				try {
					trainingData = (Map<String, List<DataInstance>>) weka.core.SerializationHelper.read("test424-3.data");
					demo = true;
					chord = false;
					classifier.train(trainingData);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			String guessedLabel = classifier.classify(captureInstance(null));
			text("classified as: " + guessedLabel, 20, 30);
		}
		else if (key == 'c') {
			if(true) {
				System.out.println("generating new object");
				classifier = new MLClassifier();
				try {
					demo = false;
					chord = true;
					trainingData = (Map<String, List<DataInstance>>) weka.core.SerializationHelper.read("test424-4.data");
					classifier.train(trainingData);
					//classifier.classifier = (SMO) weka.core.SerializationHelper.read("test421-2.model");
					//classifier.classattr = (Attribute) weka.core.SerializationHelper.read("test421-2.attr");
					/*
					List address = new ArrayList();
					address.add("chord1");
					address.add("quiet");
					address.add("chord2");
					classifier.featureCalc = new FeatureCalc(address);
					
					if(classifier.featureCalc == null)
					{
						System.out.println("It is truely null");
					}
					*/
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			String guessedLabel = classifier.classify(captureInstance(null));
			text("classified as: " + guessedLabel, 20, 30);
		}
			
		else {
			trainingData.get(classNames[classIndex]).add(captureInstance(classNames[classIndex]));
		}
	}

}